# Real-time Dashboard (Server)

**Install dependencies**

```
cd server
yarn
```

**Start the server**

```
yarn start
```

Server will be running at [http://localhost:4000/](http://localhost:4000/). The below UI will be rendered

![GraphQL UI](graphql_ui.png)